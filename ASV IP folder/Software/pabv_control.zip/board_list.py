#!/usr/bin/env python
from  arduino_tools import cli
c=cli()
c.list()

